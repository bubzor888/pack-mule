package com.dnd.packmule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PackMuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PackMuleApplication.class, args);
	}

}
